Oral Exam 1
===========

This folder contains the problems selected from the
class grid that are prepared for the first oral
examination.
