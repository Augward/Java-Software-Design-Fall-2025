Homework0
===========

This folder contains the problem solution for Homeowrk 0.
