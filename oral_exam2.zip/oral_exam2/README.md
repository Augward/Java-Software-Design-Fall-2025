Oral Exam 2
===========

This folder contains the problems selected from the
class grid that are prepared for the second oral
examination.
